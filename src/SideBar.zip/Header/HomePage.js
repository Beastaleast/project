import React from "react";
import Newhead from "./Newhead";

function HomePage() {
  return (
    <div >
      <Newhead />
    </div>
  );
}

export default HomePage;
