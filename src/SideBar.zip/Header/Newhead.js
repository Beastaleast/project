import React from "react";
import "./Newhead.css";

export default function Newhead() {
  return (
    <div className="Newhead">
      <img src="Yourganik PNG Logo(1).jpg" />
      <div>
        <h1>Welcome to the GOOD GUT PROJECT</h1>
      </div>
      <div>
        <img src="2815428.png" />
      </div>
    </div>
  );
}
