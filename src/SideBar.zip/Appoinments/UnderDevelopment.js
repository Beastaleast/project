import React from 'react';
import './UnderDevelopment.css';

const UnderDevelopment = () => {
  return (
    <div className="under-construction-container">
      <h2 className="under-construction-text">This page is under development!</h2>
    </div>
  );
};

export default UnderDevelopment;
