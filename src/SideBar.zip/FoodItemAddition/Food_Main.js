import React from "react";
import "./Food_Item.css";
import Food_Item from "./Food_Item";

function Food_Main() {
  return (
    <div>
      <Food_Item />
    </div>
  );
}

export default Food_Main;
