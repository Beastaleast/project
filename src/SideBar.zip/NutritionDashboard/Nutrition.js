import React from "react";

import Nut from "./Nut";


function Nutrition() {
  return (
    <div>
      <Nut />
    </div>
  );
}

export default Nutrition;
