import React from "react";

import E_Cards1 from "./E_Cards1";

import img from "../images/Yourganik PNG Logo(1).jpg";

function E_Cards() {
  return (
    <div>
      <div className="comp">
        <E_Cards1 img={img} />
      </div>
    </div>
  );
}

export default E_Cards;
