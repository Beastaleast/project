import React from "react";

import Cle from "./Cle";

function Cleints_Dashboard() {
  return (
    <div>
     
      <Cle />
    </div>
  );
}

export default Cleints_Dashboard;
