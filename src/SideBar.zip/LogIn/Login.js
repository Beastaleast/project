import React from 'react'
import Login1 from './Login1'



function Login() {
  return (
    <div>
   
      <Login1/>
    </div>
  )
}

export default Login
