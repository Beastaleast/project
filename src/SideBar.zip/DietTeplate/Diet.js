import React from 'react';
import './Diet.css';

const Diet = () => {
  return (
    <div className="under-construction-container">
      <h2 className="under-construction-text">This page is under development!</h2>
    </div>
  );
};

export default Diet;
