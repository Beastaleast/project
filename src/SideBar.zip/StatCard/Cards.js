import React from "react";
import "./Cards.css";

function Cards() {
  return (
    <div className="Home_Cards">
      <div className="Card_Group">
        <div className="Peoplecard">
          <p>11</p>
          <p>Nutritonist</p>
        </div>

        <div className="Peoplecard">
          <p>13</p>
          <p>Cleints</p>
        </div>

        <div className="Peoplecard">
          <p>11</p>
          <p>Nutritonist</p>
        </div>

        <div className="Peoplecard">
          <p>13</p>
          <p>Cleints</p>
        </div>

        <div className="Peoplecard">
          <p>11</p>
          <p>Nutritonist</p>
        </div>

        <div className="Peoplecard">
          <p>13</p>
          <p>Cleints</p>
        </div>

        <div className="Peoplecard">
          <p>11</p>
          <p>Nutritonist</p>
        </div>

        <div className="Peoplecard">
          <p>13</p>
          <p>Cleints</p>
        </div>

        <div className="Peoplecard">
          <p>11</p>
          <p>Nutritonist</p>
        </div>

        <div className="Peoplecard">
          <p>13</p>
          <p>Cleints</p>
        </div>
      </div>
    </div>
  );
}

export default Cards;
