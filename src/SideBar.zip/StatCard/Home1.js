import React from "react";
import Cards from "./Cards";

function Home1() {
  return (
    <div>
      <Cards />
    </div>
  );
}

export default Home1;
