import React from "react";

import SinUp1 from "./SinUp1";

function SinUP() {
  return (
    <div>
      <SinUp1 />
    </div>
  );
}

export default SinUP;
